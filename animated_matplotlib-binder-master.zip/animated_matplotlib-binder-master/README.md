[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/fomightez/animated_matplotlib-binder/master?filepath=index.ipynb)

# animated_matplotlib-binder
This repository demonstrates animated plots with Matplotlib in notebooks served via the Binder system.  
For now this uses the classic notebook interface; however, a solution that works in JupyterLab is linked at the top of the notebook that launches.

Click on `launch binder` badge above to spin up a sesion where you can run animated plots.
